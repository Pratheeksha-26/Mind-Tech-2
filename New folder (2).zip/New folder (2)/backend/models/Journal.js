const mongoose = require('mongoose');

const journalSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    required: true,
    default: Date.now
  },
  content: {
    type: String,
    required: true,
    trim: true
  },
  mood: {
    type: String,
    enum: ['happy', 'sad', 'neutral', 'stressed', 'anxious', 'angry', 'excited', 'tired'],
    default: 'neutral'
  },
  tags: [{
    type: String,
    trim: true
  }],
  sentimentScore: {
    type: Number,
    min: -1,
    max: 1,
    default: 0
  },
  wordCount: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// Index for efficient queries
journalSchema.index({ user: 1, date: -1 });
journalSchema.index({ user: 1, mood: 1 });

module.exports = mongoose.model('Journal', journalSchema);