const express = require('express');
const router = express.Router();
const Journal = require('../models/Journal');

// Save journal
router.post('/', async (req, res) => {
  try {
    const { userId, content, mood } = req.body;

    const journal = new Journal({
      user: userId,
      content,
      mood,
      wordCount: content.split(' ').length
    });

    await journal.save();
    res.status(201).json(journal);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get journals
router.get('/:userId', async (req, res) => {
  try {
    const journals = await Journal.find({ user: req.params.userId })
      .sort({ date: -1 });
    res.json(journals);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
