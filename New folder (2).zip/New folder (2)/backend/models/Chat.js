const mongoose = require('mongoose');

const chatSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },

  date: {
    type: String, // YYYY-MM-DD
    required: true
  },

  messages: [
    {
      sender: {
        type: String,
        enum: ['user', 'bot'],
        required: true
      },
      text: {
        type: String,
        required: true
      },
      time: {
        type: String
      }
    }
  ]
}, { timestamps: true });

chatSchema.index({ user: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('Chat', chatSchema);
