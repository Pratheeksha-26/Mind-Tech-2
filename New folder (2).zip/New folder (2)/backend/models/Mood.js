const mongoose = require('mongoose');

const moodSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    required: true,
    default: Date.now
  },
  mood: {
    type: String,
    required: true,
    enum: ['happy', 'sad', 'neutral', 'stressed', 'anxious', 'angry', 'excited', 'tired', 'calm', 'energized']
  },
  intensity: {
    type: Number,
    min: 1,
    max: 10,
    default: 5
  },
  notes: {
    type: String,
    trim: true,
    maxlength: 500
  },
  factors: [{
    type: String,
    trim: true
  }],
  location: {
    type: String,
    trim: true
  },
  weather: {
    type: String,
    trim: true
  }
}, {
  timestamps: true
});

// Index for efficient queries
moodSchema.index({ user: 1, date: -1 });
moodSchema.index({ user: 1, mood: 1 });

// Ensure only one mood entry per day per user
moodSchema.index({ user: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('Mood', moodSchema);