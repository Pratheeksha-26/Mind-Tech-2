const express = require('express');
const router = express.Router();
const Mood = require('../models/Mood');

// Add / update today mood
router.post('/', async (req, res) => {
  try {
    const { userId, mood, intensity, notes } = req.body;

    const today = new Date().toISOString().split('T')[0];

    const moodEntry = await Mood.findOneAndUpdate(
      { user: userId, date: today },
      { mood, intensity, notes, date: today },
      { upsert: true, new: true }
    );

    res.status(201).json(moodEntry);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get user moods
router.get('/:userId', async (req, res) => {
  try {
    const moods = await Mood.find({ user: req.params.userId })
      .sort({ date: -1 });
    res.json(moods);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
