const express = require('express');
const router = express.Router();
const Mood = require('../models/Mood');
const User = require('../models/User');
const { authMiddleware } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

// Apply auth middleware to all routes
router.use(authMiddleware);

// @route   POST /api/mood
// @desc    Log a mood entry
// @access  Private
router.post('/', [
  body('mood')
    .notEmpty()
    .withMessage('Mood is required')
    .isIn(['happy', 'sad', 'neutral', 'stressed', 'anxious', 'angry', 'excited', 'tired', 'calm', 'energized']),
  body('intensity')
    .optional()
    .isInt({ min: 1, max: 10 })
    .withMessage('Intensity must be between 1 and 10'),
  body('notes')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Notes cannot exceed 500 characters')
], async (req, res) => {
  try {
    // Validate input
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { mood, intensity, notes, factors, location, weather } = req.body;
    
    // Get today's date at midnight for comparison
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Check if mood already logged today
    const existingMood = await Mood.findOne({
      user: req.user._id,
      date: { $gte: today, $lt: tomorrow }
    });

    let moodEntry;
    
    if (existingMood) {
      // Update existing entry
      moodEntry = await Mood.findOneAndUpdate(
        { _id: existingMood._id, user: req.user._id },
        {
          mood,
          intensity: intensity || 5,
          notes,
          factors: factors || [],
          location,
          weather
        },
        { new: true, runValidators: true }
      );
    } else {
      // Create new entry
      moodEntry = new Mood({
        user: req.user._id,
        mood,
        intensity: intensity || 5,
        notes,
        factors: factors || [],
        location,
        weather
      });

      await moodEntry.save();

      // Update user stats (only for registered users)
      if (!req.user.isGuest) {
        await User.findByIdAndUpdate(req.user._id, {
          $inc: { 'stats.daysTracked': 1 }
        });
      }
    }

    res.status(201).json({
      message: existingMood ? 'Mood updated successfully' : 'Mood logged successfully',
      mood: moodEntry
    });
  } catch (error) {
    console.error(error);
    
    // Handle duplicate entry error
    if (error.code === 11000) {
      return res.status(400).json({ 
        error: 'You have already logged your mood for today. Use update instead.' 
      });
    }
    
    res.status(500).json({ error: 'Server error logging mood' });
  }
});

// @route   GET /api/mood
// @desc    Get mood entries with optional filtering
// @access  Private
router.get('/', async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 30, 
      mood, 
      startDate, 
      endDate,
      sortBy = 'date',
      sortOrder = 'desc'
    } = req.query;
    
    const query = { user: req.user._id };
    
    // Apply filters
    if (mood) {
      query.mood = mood;
    }
    
    if (startDate || endDate) {
      query.date = {};
      if (startDate) query.date.$gte = new Date(startDate);
      if (endDate) query.date.$lte = new Date(endDate);
    }

    const sort = {};
    sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

    const moods = await Mood.find(query)
      .sort(sort)
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .lean();

    const total = await Mood.countDocuments(query);

    res.json({
      moods,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching mood entries' });
  }
});

// @route   GET /api/mood/today
// @desc    Get today's mood entry
// @access  Private
router.get('/today', async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const moodEntry = await Mood.findOne({
      user: req.user._id,
      date: { $gte: today, $lt: tomorrow }
    });

    res.json({ mood: moodEntry });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching today\'s mood' });
  }
});

// @route   GET /api/mood/stats/summary
// @desc    Get mood statistics and trends
// @access  Private
router.get('/stats/summary', async (req, res) => {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Mood distribution for the last 30 days
    const moodDistribution = await Mood.aggregate([
      {
        $match: {
          user: req.user._id,
          date: { $gte: thirtyDaysAgo }
        }
      },
      {
        $group: {
          _id: '$mood',
          count: { $sum: 1 },
          avgIntensity: { $avg: '$intensity' }
        }
      },
      {
        $sort: { count: -1 }
      }
    ]);

    // Daily moods for the last 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const dailyMoods = await Mood.aggregate([
      {
        $match: {
          user: req.user._id,
          date: { $gte: sevenDaysAgo }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$date' }
          },
          mood: { $first: '$mood' },
          intensity: { $first: '$intensity' }
        }
      },
      {
        $sort: { '_id': 1 }
      }
    ]);

    // Mood trends by day of week
    const moodByDayOfWeek = await Mood.aggregate([
      {
        $match: { user: req.user._id }
      },
      {
        $group: {
          _id: {
            $dayOfWeek: '$date'
          },
          moods: { $push: '$mood' },
          avgIntensity: { $avg: '$intensity' }
        }
      },
      {
        $sort: { '_id': 1 }
      }
    ]);

    // Most common mood factors
    const commonFactors = await Mood.aggregate([
      {
        $match: { user: req.user._id }
      },
      {
        $unwind: '$factors'
      },
      {
        $group: {
          _id: '$factors',
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      },
      {
        $limit: 10
      }
    ]);

    // Calculate streaks
    const allMoods = await Mood.find({ user: req.user._id })
      .sort({ date: -1 })
      .lean();

    let currentStreak = 0;
    let longestStreak = 0;
    let tempStreak = 0;
    let lastDate = null;

    allMoods.forEach((entry, index) => {
      const entryDate = new Date(entry.date).toDateString();
      
      if (index === 0) {
        // Check if today's mood is logged
        const today = new Date().toDateString();
        if (entryDate === today) {
          currentStreak = 1;
          tempStreak = 1;
        }
      } else if (lastDate) {
        const lastEntryDate = new Date(lastDate);
        const currentEntryDate = new Date(entry.date);
        
        // Check if consecutive days
        const diffTime = Math.abs(lastEntryDate - currentEntryDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
          tempStreak++;
          if (tempStreak > longestStreak) {
            longestStreak = tempStreak;
          }
        } else {
          tempStreak = 1;
        }
      }
      
      lastDate = entry.date;
    });

    res.json({
      moodDistribution,
      dailyMoods,
      moodByDayOfWeek,
      commonFactors,
      streaks: {
        current: currentStreak,
        longest: longestStreak
      },
      totalEntries: allMoods.length,
      avgIntensity: moodDistribution.length > 0 
        ? moodDistribution.reduce((sum, item) => sum + item.avgIntensity, 0) / moodDistribution.length 
        : 0
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching mood statistics' });
  }
});

// @route   GET /api/mood/calendar/:year/:month
// @desc    Get mood entries for a specific month (calendar view)
// @access  Private
router.get('/calendar/:year/:month', async (req, res) => {
  try {
    const { year, month } = req.params;
    
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59, 999);

    const moods = await Mood.find({
      user: req.user._id,
      date: { $gte: startDate, $lte: endDate }
    }).sort({ date: 1 });

    // Format for calendar view
    const calendarData = {};
    moods.forEach(mood => {
      const day = new Date(mood.date).getDate();
      calendarData[day] = {
        mood: mood.mood,
        intensity: mood.intensity,
        hasNotes: !!mood.notes
      };
    });

    res.json({
      year: parseInt(year),
      month: parseInt(month),
      moods: calendarData,
      totalDays: moods.length
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error fetching calendar data' });
  }
});

// @route   PUT /api/mood/:id
// @desc    Update a mood entry
// @access  Private
router.put('/:id', [
  body('mood')
    .optional()
    .isIn(['happy', 'sad', 'neutral', 'stressed', 'anxious', 'angry', 'excited', 'tired', 'calm', 'energized']),
  body('intensity')
    .optional()
    .isInt({ min: 1, max: 10 }),
  body('notes')
    .optional()
    .trim()
    .isLength({ max: 500 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const updateData = {};
    if (req.body.mood !== undefined) updateData.mood = req.body.mood;
    if (req.body.intensity !== undefined) updateData.intensity = req.body.intensity;
    if (req.body.notes !== undefined) updateData.notes = req.body.notes;
    if (req.body.factors !== undefined) updateData.factors = req.body.factors;
    if (req.body.location !== undefined) updateData.location = req.body.location;
    if (req.body.weather !== undefined) updateData.weather = req.body.weather;

    const moodEntry = await Mood.findOneAndUpdate(
      {
        _id: req.params.id,
        user: req.user._id
      },
      updateData,
      { new: true, runValidators: true }
    );

    if (!moodEntry) {
      return res.status(404).json({ error: 'Mood entry not found' });
    }

    res.json({
      message: 'Mood entry updated successfully',
      mood: moodEntry
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error updating mood entry' });
  }
});

// @route   DELETE /api/mood/:id
// @desc    Delete a mood entry
// @access  Private
router.delete('/:id', async (req, res) => {
  try {
    const moodEntry = await Mood.findOneAndDelete({
      _id: req.params.id,
      user: req.user._id
    });

    if (!moodEntry) {
      return res.status(404).json({ error: 'Mood entry not found' });
    }

    // Update user stats (only for registered users)
    if (!req.user.isGuest) {
      await User.findByIdAndUpdate(req.user._id, {
        $inc: { 'stats.daysTracked': -1 }
      });
    }

    res.json({ message: 'Mood entry deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error deleting mood entry' });
  }
});

module.exports = router;