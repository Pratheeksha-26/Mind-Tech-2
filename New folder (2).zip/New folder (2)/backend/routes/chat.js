const express = require('express');
const router = express.Router();
const Chat = require('../models/Chat');

/* 🔹 SAVE MESSAGE */
router.post('/send', async (req, res) => {
  try {
    const { userId, sender, text } = req.body;
    const date = new Date().toISOString().split('T')[0];
    const time = new Date().toLocaleTimeString();

    let chat = await Chat.findOne({ user: userId, date });

    if (!chat) {
      chat = new Chat({
        user: userId,
        date,
        messages: []
      });
    }

    chat.messages.push({ sender, text, time });
    await chat.save();

    res.json({ message: 'Message saved' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

/* 🔹 GET TODAY CHAT */
router.get('/today/:userId', async (req, res) => {
  try {
    const date = new Date().toISOString().split('T')[0];
    const chat = await Chat.findOne({ user: req.params.userId, date });
    res.json(chat ? chat.messages : []);
  } catch (err) {
    res.status(500).json({ message: 'Failed to load today chat' });
  }
});

/* 🔹 GET CHAT HISTORY (DATES ONLY) */
router.get('/history/:userId', async (req, res) => {
  const chats = await Chat.find({ user: req.params.userId })
    .select('date')
    .sort({ date: -1 });

  res.json(chats);
});

/* 🔹 GET CHAT BY DATE */
router.get('/:userId/:date', async (req, res) => {
  const chat = await Chat.findOne({
    user: req.params.userId,
    date: req.params.date
  });

  res.json(chat ? chat.messages : []);
});

module.exports = router;
