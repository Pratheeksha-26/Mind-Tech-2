const express = require('express');
const router = express.Router();
const axios = require('axios');
const { authMiddleware } = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(authMiddleware);

// Groq AI Configuration
const GROQ_API_KEY = process.env.GROQ_API_KEY || "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";
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_MODEL = "llama-3.1-8b-instant";

// Enhanced system prompt for emotional support
const SYSTEM_PROMPT = `You are MoodLight, a compassionate emotional wellness companion with expertise in mental health support. Your role is to provide empathetic, understanding, and supportive responses to users discussing their emotional wellbeing.

Key guidelines:
- Be warm, validating, and non-judgmental
- Offer practical coping strategies when appropriate
- Help users reframe negative thoughts constructively
- Suggest mindfulness exercises or breathing techniques when relevant
- Maintain professional boundaries while being deeply compassionate
- Focus on emotional support rather than clinical diagnosis
- Use encouraging and hopeful language
- Keep responses conversational and natural (under 150 words)
- Ask thoughtful questions to encourage reflection

Remember: You're here to support, listen, and help users feel understood and validated. Never provide medical advice.`;

// Store chat history (in production, this should be in a database)
const chatHistories = new Map();

// @route   POST /api/chat
// @desc    Send a message to the AI chat
// @access  Private
router.post('/', async (req, res) => {
  try {
    const { message, mood } = req.body;
    
    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Get or initialize chat history for user
    const userId = req.user._id.toString();
    if (!chatHistories.has(userId)) {
      chatHistories.set(userId, []);
    }
    
    const userHistory = chatHistories.get(userId);
    
    // Add user message to history
    userHistory.push({ role: 'user', content: message });
    
    // Keep only last 10 messages to manage context length
    if (userHistory.length > 20) {
      userHistory.splice(0, userHistory.length - 10);
    }
    
    // Prepare messages for API
    const messages = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...userHistory.slice(-10) // Last 10 messages for context
    ];

    // Add mood context if provided
    if (mood && mood !== 'neutral') {
      messages.splice(1, 0, { 
        role: 'system', 
        content: `User's current mood: ${mood}. Please respond with appropriate sensitivity.` 
      });
    }

    let aiResponse;
    
    try {
      // Call Groq AI API
      const response = await axios.post(
        GROQ_API_URL,
        {
          model: GROQ_MODEL,
          messages: messages,
          temperature: 0.7,
          max_tokens: 500,
          top_p: 0.9,
          stream: false
        },
        {
          headers: {
            'Authorization': `Bearer ${GROQ_API_KEY}`,
            'Content-Type': 'application/json'
          },
          timeout: 10000 // 10 second timeout
        }
      );

      if (response.data.choices && response.data.choices.length > 0) {
        aiResponse = response.data.choices[0].message.content.trim();
      } else {
        throw new Error('Invalid response format from AI');
      }
    } catch (apiError) {
      console.error('Groq API Error:', apiError.response?.data || apiError.message);
      
      // Fallback response when API fails
      aiResponse = getFallbackResponse(mood || 'neutral', message);
    }
    
    // Add AI response to history
    userHistory.push({ role: 'assistant', content: aiResponse });
    
    // Update chat history storage
    chatHistories.set(userId, userHistory);
    
    res.json({
      success: true,
      response: aiResponse,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Chat Error:', error);
    res.status(500).json({ 
      error: 'Failed to process chat message',
      message: error.message 
    });
  }
});

// @route   GET /api/chat/history
// @desc    Get chat history for the user
// @access  Private
router.get('/history', async (req, res) => {
  try {
    const userId = req.user._id.toString();
    const history = chatHistories.get(userId) || [];
    
    // Format history for frontend
    const formattedHistory = history.map(msg => ({
      sender: msg.role === 'user' ? 'user' : 'bot',
      text: msg.content,
      timestamp: new Date().toISOString() // In production, store actual timestamps
    }));
    
    res.json({
      history: formattedHistory,
      totalMessages: formattedHistory.length
    });
  } catch (error) {
    console.error('History Error:', error);
    res.status(500).json({ error: 'Failed to fetch chat history' });
  }
});

// @route   DELETE /api/chat/history
// @desc    Clear chat history for the user
// @access  Private
router.delete('/history', async (req, res) => {
  try {
    const userId = req.user._id.toString();
    chatHistories.delete(userId);
    
    res.json({ 
      success: true, 
      message: 'Chat history cleared' 
    });
  } catch (error) {
    console.error('Clear History Error:', error);
    res.status(500).json({ error: 'Failed to clear chat history' });
  }
});

// @route   GET /api/chat/status
// @desc    Check AI service status
// @access  Private
router.get('/status', async (req, res) => {
  try {
    // Try a lightweight request to check API status
    const testResponse = await axios.get('https://api.groq.com/openai/v1/models', {
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      timeout: 5000
    });
    
    res.json({
      service: 'Groq AI',
      status: 'connected',
      model: GROQ_MODEL,
      message: 'AI chat service is operational'
    });
  } catch (error) {
    res.json({
      service: 'Groq AI',
      status: 'offline',
      model: GROQ_MODEL,
      message: 'AI service is currently unavailable. Using fallback responses.',
      fallback: true
    });
  }
});

// Fallback responses for when API is unavailable
function getFallbackResponse(currentMood, userMessage) {
  const message = userMessage.toLowerCase();
  
  // Mood-specific responses
  const moodResponses = {
    happy: [
      "I'm so glad you're feeling happy! What's bringing you joy today?",
      "That's wonderful to hear! Happiness is contagious. Want to share what's making you smile?",
      "Your positive energy is uplifting! How can we build on this good feeling?"
    ],
    sad: [
      "I hear that you're feeling sad, and I want you to know your feelings are completely valid.",
      "It's okay to feel sad sometimes. I'm here with you through this.",
      "Thank you for sharing how you're feeling. Would you like to talk more about what's on your mind?"
    ],
    stressed: [
      "Stress can feel overwhelming. Let's take a moment to breathe together.",
      "I understand you're feeling stressed. What's one small thing that might help right now?",
      "That sounds really challenging. Remember to be gentle with yourself."
    ],
    anxious: [
      "Anxiety can be really tough. Let's try a grounding exercise: name three things you can see right now.",
      "I'm here with you. Would you like to try a simple breathing technique together?",
      "Thank you for sharing this with me. What's one thing that usually helps when you feel this way?"
    ],
    angry: [
      "Anger is a valid emotion that often points to something important. Would you like to explore what might be underneath these feelings?",
      "It's okay to feel angry. Let's talk about what's bothering you in a safe space.",
      "I hear your frustration. Would it help to talk about what happened?"
    ],
    neutral: [
      "Thanks for checking in. How has your day been so far?",
      "I'm here to listen. What's on your mind today?",
      "Sometimes neutral days are opportunities for reflection. How are you feeling about things?"
    ]
  };

  // Keyword-based responses
  if (message.includes('sad') || message.includes('depressed') || message.includes('unhappy')) {
    return "I can hear the sadness in your words. It takes courage to share these feelings. Would you like to try a breathing exercise together, or just talk about what's weighing on your heart?";
  }
  
  if (message.includes('anxious') || message.includes('worried') || message.includes('nervous')) {
    return "Anxiety can feel overwhelming. Let's ground ourselves together. What's one thing you can see, hear, and feel right now?";
  }
  
  if (message.includes('happy') || message.includes('excited') || message.includes('joy')) {
    return "Your happiness is beautiful to witness! What's making you feel this way? I'd love to celebrate this moment with you.";
  }
  
  if (message.includes('angry') || message.includes('frustrated') || message.includes('mad')) {
    return "Anger is a valid emotion that often points to something important. Would you like to explore what might be underneath these feelings?";
  }
  
  if (message.includes('lonely') || message.includes('alone') || message.includes('isolated')) {
    return "Loneliness can be really hard. I'm here with you right now, and you're not alone in this feeling.";
  }

  if (message.includes('stress') || message.includes('overwhelmed')) {
    return "I hear that you're feeling stressed. Let's break things down together. What's one small step you can take right now?";
  }

  if (message.includes('tired') || message.includes('exhausted') || message.includes('fatigue')) {
    return "It sounds like you could use some rest. Remember that taking care of yourself is important too. What would help you recharge?";
  }

  if (message.includes('thank') || message.includes('thanks')) {
    return "You're very welcome! I'm here whenever you need to talk. How are you feeling now?";
  }

  // Default to mood-based response
  const responses = moodResponses[currentMood] || moodResponses.neutral;
  return responses[Math.floor(Math.random() * responses.length)];
}

module.exports = router;