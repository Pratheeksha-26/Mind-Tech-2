# Algorithm-Avengers
MoodLight is a web app with an AI chatbot designed to support users during emotional highs and lows. It includes Grok poems to offer comfort, reflection, and inspiration.
